const { commands } = require("../core/commandLoader")

module.exports = {
  pattern:  "menu",
  desc:     "Show all available commands",
  usage:    ".menu",
  category: "general",

  async run({ sock, from, msg }) {
    let text = "📜 *CYBER X — Command Menu*\n\n"

    for (const cmd of commands.values()) {
      text += `• *.${cmd.pattern}* — ${cmd.desc}\n`
    }

    await sock.sendMessage(from, { text }, { quoted: msg })
  },
}
