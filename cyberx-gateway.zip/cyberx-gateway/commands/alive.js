module.exports = {
  pattern:  "alive",
  desc:     "Check session uptime",
  usage:    ".alive",
  category: "general",

  async run({ sock, from, msg, userId }) {
    const uptimeSec = Math.floor(process.uptime())
    const h = Math.floor(uptimeSec / 3600)
    const m = Math.floor((uptimeSec % 3600) / 60)
    const s = uptimeSec % 60

    await sock.sendMessage(from, {
      text: `⚡ *CYBER X* is alive!\n\nSession: ${userId}\nUptime: ${h}h ${m}m ${s}s`,
    }, { quoted: msg })
  },
}
