// ─────────────────────────────────────────────────────────────────────────────
// index.js  —  CYBER X Gateway  |  Entry Point
// ─────────────────────────────────────────────────────────────────────────────

const express = require("express")

const sessionManager = require("./core/sessionManager")
const apiRoutes      = require("./routes/api")

const app = express()
app.use(express.json())

app.get("/", (req, res) => res.send("⚡ CYBER X Gateway — online"))
app.use("/", apiRoutes)

const PORT = process.env.PORT || 3000

async function main() {
  app.listen(PORT, () => console.log(`[WEB] LIVE → ${PORT}`))

  // Restore every session that was previously linked (has saved creds)
  await sessionManager.loadAllSessions()

  console.log("⚡ CYBER X Gateway ONLINE")
}

main().catch((e) => {
  console.error("[FATAL]", e)
  process.exit(1)
})

process.on("unhandledRejection", (err) => {
  console.error("[UNHANDLED REJECTION]", err)
})

process.on("uncaughtException", (err) => {
  console.error("[UNCAUGHT EXCEPTION]", err)
})
