// ─────────────────────────────────────────────────────────────────────────────
// routes/api.js  —  CYBER X Gateway  |  API Routes
//
//   POST /connect            { userId }              → start session, generates QR
//   GET  /qr/:userId                                   → returns current QR / status
//   POST /send                { userId, to, message } → send a text message
//   GET  /status/:userId                               → connection status
//   POST /logout              { userId }              → logout + wipe session
// ─────────────────────────────────────────────────────────────────────────────

const express = require("express")
const router  = express.Router()

const sessionManager = require("../core/sessionManager")
const { log } = require("../core/logger")

// ── POST /connect ─────────────────────────────────────────────────────────────
router.post("/connect", async (req, res) => {
  const { userId } = req.body || {}
  if (!userId) {
    return res.status(400).json({ ok: false, error: "userId is required" })
  }

  const existing = sessionManager.getSession(userId)
  if (existing && existing.status === "connected") {
    return res.json({ ok: true, status: "connected", message: "Session already connected" })
  }

  await sessionManager.startSession(userId)
  res.json({ ok: true, message: "Session starting — poll GET /qr/:userId for the QR code" })
})

// ── GET /qr/:userId ────────────────────────────────────────────────────────────
router.get("/qr/:userId", (req, res) => {
  const entry = sessionManager.getSession(req.params.userId)

  if (!entry) {
    return res.json({ ok: true, status: "not_started" })
  }

  res.json({
    ok: true,
    status: entry.status,             // "connecting" | "connected" | "disconnected"
    qr: entry.qr || null,              // data:image/png;base64,... — render as <img src>
  })
})

// ── GET /status/:userId ────────────────────────────────────────────────────────
router.get("/status/:userId", (req, res) => {
  const entry = sessionManager.getSession(req.params.userId)

  if (!entry) {
    return res.json({ ok: true, status: "not_started", connected: false })
  }

  res.json({
    ok: true,
    status: entry.status,
    connected: entry.status === "connected",
  })
})

// ── POST /send ─────────────────────────────────────────────────────────────────
router.post("/send", async (req, res) => {
  const { userId, to, message } = req.body || {}

  if (!userId || !to || !message) {
    return res.status(400).json({ ok: false, error: "userId, to, and message are required" })
  }

  const entry = sessionManager.getSession(userId)
  if (!entry || entry.status !== "connected") {
    return res.status(409).json({ ok: false, error: "Session not connected" })
  }

  try {
    // Accept either a raw number ("234801234567") or a full JID
    const jid = to.includes("@") ? to : `${to.replace(/\D/g, "")}@s.whatsapp.net`

    await entry.sock.sendMessage(jid, { text: message })
    log(userId, `📤 Sent message to ${jid}`)

    res.json({ ok: true, message: "Sent" })
  } catch (e) {
    log(userId, `✗ Send failed: ${e.message}`)
    res.status(500).json({ ok: false, error: e.message })
  }
})

// ── POST /logout ───────────────────────────────────────────────────────────────
router.post("/logout", async (req, res) => {
  const { userId } = req.body || {}
  if (!userId) {
    return res.status(400).json({ ok: false, error: "userId is required" })
  }

  await sessionManager.logoutSession(userId)
  res.json({ ok: true, message: "Logged out" })
})

module.exports = router
