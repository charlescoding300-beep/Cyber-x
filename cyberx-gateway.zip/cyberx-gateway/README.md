# CYBER X Gateway — Multi-User WhatsApp Gateway

A Node.js + Baileys backend where **each user links their own WhatsApp
account** via QR code. Every linked account gets its own session folder,
its own socket, and runs commands independently.

## Folder structure

```
cyberx-gateway/
├── index.js              # entry point
├── package.json
├── core/
│   ├── sessionManager.js  # multi-user sessions, QR, auto-reconnect
│   ├── commandLoader.js    # loads commands/ — same pattern as main CYBER X
│   └── logger.js           # per-user activity logs
├── commands/
│   ├── menu.js
│   ├── ping.js
│   └── alive.js
├── routes/
│   └── api.js             # /connect /qr /send /status /logout
├── sessions/               # per-user auth state — created automatically
│   └── <userId>/           # one folder per linked account
└── logs/                    # per-user activity logs (<userId>.log)
```

## Setup

```bash
npm install
npm start
```

Server starts on `http://localhost:3000` (set `PORT` env var to change).

On boot, it scans `sessions/` and automatically reconnects any user who
was previously linked — no re-scan needed unless they logged out.

## API usage

### 1. Link a new account

```bash
curl -X POST http://localhost:3000/connect \
  -H "Content-Type: application/json" \
  -d '{"userId": "user1"}'
```

### 2. Get the QR code (poll every 2-3s until status is "connected")

```bash
curl http://localhost:3000/qr/user1
```

Response:
```json
{
  "ok": true,
  "status": "connecting",
  "qr": "data:image/png;base64,iVBORw0KG..."
}
```

Render `qr` directly as `<img src="...">` in a frontend (create.xyz, etc.).
Once scanned, `status` becomes `"connected"` and `qr` becomes `null`.

### 3. Check status

```bash
curl http://localhost:3000/status/user1
```

```json
{ "ok": true, "status": "connected", "connected": true }
```

### 4. Send a message via that user's WhatsApp

```bash
curl -X POST http://localhost:3000/send \
  -H "Content-Type: application/json" \
  -d '{"userId": "user1", "to": "2348012345678", "message": "Hello from CYBER X!"}'
```

`to` accepts a raw number or a full JID (`...@s.whatsapp.net` / `...@g.us`).

### 5. Logout (wipes session permanently)

```bash
curl -X POST http://localhost:3000/logout \
  -H "Content-Type: application/json" \
  -d '{"userId": "user1"}'
```

## Commands (per-session)

Once a user's WhatsApp is linked, messages to/from that account are handled
by `core/commandLoader.js`, which loads everything in `commands/`. Each
linked account runs commands independently — there's no shared state between
users.

Included: `.menu`, `.ping`, `.alive`.

### Adding a new command

Drop a file in `commands/`, same shape as the main CYBER X bot:

```js
module.exports = {
  pattern:  "hello",
  desc:     "Say hello",
  usage:    ".hello",
  category: "general",

  async run({ sock, from, msg, userId, args }) {
    await sock.sendMessage(from, { text: "Hello! 👋" }, { quoted: msg })
  },
}
```

It's picked up automatically — no manual registration. `run()` receives:
- `sock` — that user's Baileys socket
- `from` — the chat JID to reply to
- `msg` — the raw message
- `userId` — which linked account this is
- `args` — words after the command
- `text` — the full message text

## Stability notes

- **Auto-reconnect**: any disconnect other than an explicit logout triggers
  a reconnect after 2s. Sessions persist in `sessions/<userId>/creds.json`.
- **Memory-leak prevention**: before reconnecting or logging out, the old
  socket's event listeners are removed and its websocket is closed
  (`cleanupSocket()`), so dead connections don't accumulate timers/listeners.
- **Multiple users**: each session is an independent socket in memory —
  one user's disconnect/reconnect doesn't affect others.

## Deployment

### Local / VPS (recommended)

Sessions are stored on disk in `sessions/`. On a VPS this persists across
restarts naturally — just run with a process manager:

```bash
npm install -g pm2
pm2 start index.js --name cyberx-gateway
pm2 save
```

### Render (testing only)

Render's free tier has an ephemeral filesystem — `sessions/` is wiped on
every restart/redeploy, so users would need to re-scan their QR after each
restart. Fine for testing the API/dashboard flow, but for production use a
VPS (or move auth storage to a database — ask if you want that variant).

## Frontend / dashboard integration (create.xyz, etc.)

The API is intentionally simple JSON — a dashboard just needs to:
1. `POST /connect` when a user clicks "Link WhatsApp"
2. Poll `GET /qr/:userId` every 2-3s, render `qr` as an `<img>` while
   `status === "connecting"`
3. Once `status === "connected"`, show a success state and hide the QR
4. Use `GET /status/:userId` for a "linked / not linked" badge elsewhere
5. `POST /send` for any "send a test message" feature
