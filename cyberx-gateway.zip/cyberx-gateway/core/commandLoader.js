// ─────────────────────────────────────────────────────────────────────────────
// core/commandLoader.js  —  CYBER X Gateway  |  Command Loader
//
// Loads every file in commands/, same convention as the main CYBER X bot:
//
//   module.exports = {
//     pattern:  "ping",
//     desc:     "...",
//     usage:    "...",
//     category: "...",
//     async run({ sock, from, msg, userId, args, text }) { ... }
//   }
//
// Commands are matched by prefix (default ".") + pattern, e.g. ".ping".
// Each session calls handle() independently — no shared state between users.
// ─────────────────────────────────────────────────────────────────────────────

const fs   = require("fs")
const path = require("path")
const { log } = require("./logger")

const COMMANDS_DIR = path.join(__dirname, "..", "commands")
const PREFIX = "."

let commands = new Map()

function loadCommands() {
  commands = new Map()
  if (!fs.existsSync(COMMANDS_DIR)) return

  for (const file of fs.readdirSync(COMMANDS_DIR)) {
    if (!file.endsWith(".js")) continue
    const fullPath = path.join(COMMANDS_DIR, file)
    try {
      delete require.cache[require.resolve(fullPath)]
      const cmd = require(fullPath)
      if (cmd?.pattern && typeof cmd.run === "function") {
        commands.set(cmd.pattern.toLowerCase(), cmd)
        console.log(`[CMD] ✔ Loaded .${cmd.pattern}`)
      } else {
        console.warn(`[CMD] ⚠ ${file} — missing pattern/run, skipped`)
      }
    } catch (e) {
      console.error(`[CMD] ✗ ${file}:`, e.message)
    }
  }
  console.log(`[CMD] ${commands.size} command(s) loaded`)
}

function getMessageText(msg) {
  return (
    msg.message?.conversation ||
    msg.message?.extendedTextMessage?.text ||
    msg.message?.imageMessage?.caption ||
    msg.message?.videoMessage?.caption ||
    ""
  )
}

/**
 * Route an incoming message to a matching command, scoped to one session.
 * @param {Object} ctx
 * @param {import("@whiskeysockets/baileys").WASocket} ctx.sock
 * @param {Object} ctx.msg
 * @param {string} ctx.userId
 */
async function handle({ sock, msg, userId }) {
  const text = getMessageText(msg).trim()
  if (!text.startsWith(PREFIX)) return

  const [rawCmd, ...args] = text.slice(PREFIX.length).trim().split(/\s+/)
  const pattern = rawCmd.toLowerCase()
  const cmd = commands.get(pattern)
  if (!cmd) return

  const from = msg.key.remoteJid

  try {
    log(userId, `▶ .${pattern} from ${from}`)
    await cmd.run({ sock, from, msg, userId, args, text })
  } catch (e) {
    log(userId, `✗ .${pattern} error: ${e.message}`)
    try {
      await sock.sendMessage(from, { text: `❌ Error running .${pattern}: ${e.message}` }, { quoted: msg })
    } catch {}
  }
}

loadCommands()

module.exports = {
  loadCommands,
  handle,
  get commands() { return commands },
}
