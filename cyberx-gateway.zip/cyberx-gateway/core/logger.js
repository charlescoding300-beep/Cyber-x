// ─────────────────────────────────────────────────────────────────────────────
// core/logger.js  —  CYBER X Gateway  |  Per-User Activity Logger
//
// Writes timestamped activity lines to logs/<userId>.log AND console.
// Used for: connections, disconnects, commands run, sends, errors.
// ─────────────────────────────────────────────────────────────────────────────

const fs   = require("fs")
const path = require("path")

const LOGS_DIR = path.join(__dirname, "..", "logs")
if (!fs.existsSync(LOGS_DIR)) fs.mkdirSync(LOGS_DIR, { recursive: true })

function log(userId, message) {
  const line = `[${new Date().toISOString()}] ${message}`
  console.log(`[${userId}] ${message}`)

  const file = path.join(LOGS_DIR, `${userId}.log`)
  fs.appendFile(file, line + "\n", (err) => {
    if (err) console.error(`[LOGGER] Failed writing log for ${userId}:`, err.message)
  })
}

module.exports = { log }
