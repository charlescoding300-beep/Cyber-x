// ─────────────────────────────────────────────────────────────────────────────
// core/sessionManager.js  —  CYBER X Gateway  |  Multi-User Session Manager
//
// Each user gets:
//   - their own Baileys socket, kept in memory (sessions Map)
//   - their own auth folder: /sessions/<userId>/  (useMultiFileAuthState)
//
// Commands run per-session via commandLoader — no shared state between users.
//
// Auto-reconnect: any disconnect except "logged out" triggers a reconnect.
// Memory-leak prevention: on every reconnect/stop, the old socket's websocket
// is closed and event listeners are removed before the old reference is
// dropped, so dead sockets don't keep timers/listeners alive in the background.
// ─────────────────────────────────────────────────────────────────────────────

const {
  default: makeWASocket,
  useMultiFileAuthState,
  DisconnectReason,
  fetchLatestBaileysVersion,
} = require("@whiskeysockets/baileys")

const fs     = require("fs")
const path   = require("path")
const pino   = require("pino")
const QRCode = require("qrcode")

const commandLoader = require("./commandLoader")
const { log } = require("./logger")

const SESSIONS_DIR = path.join(__dirname, "..", "sessions")
if (!fs.existsSync(SESSIONS_DIR)) fs.mkdirSync(SESSIONS_DIR, { recursive: true })

const logger = pino({ level: "silent" })

// userId -> { sock, status, qr, reconnectTimer }
const sessions = new Map()

/**
 * Start (or restart) a session for a given user.
 * @param {string} userId
 */
async function startSession(userId) {
  const sessionPath = path.join(SESSIONS_DIR, userId)
  if (!fs.existsSync(sessionPath)) fs.mkdirSync(sessionPath, { recursive: true })

  const { state, saveCreds } = await useMultiFileAuthState(sessionPath)
  const { version } = await fetchLatestBaileysVersion()

  const sock = makeWASocket({
    version,
    auth: state,
    printQRInTerminal: false,
    logger,
    browser: ["CYBER X", "Chrome", "1.0"],
  })

  // Replace any existing entry, cleaning up the old socket first
  cleanupSocket(userId)
  sessions.set(userId, { sock, status: "connecting", qr: null, reconnectTimer: null })

  sock.ev.on("creds.update", saveCreds)

  sock.ev.on("connection.update", async (update) => {
    const { connection, lastDisconnect, qr } = update
    const entry = sessions.get(userId)
    if (!entry) return

    if (qr) {
      entry.qr = await QRCode.toDataURL(qr)
      log(userId, "📷 QR generated — waiting for scan")
    }

    if (connection === "open") {
      entry.status = "connected"
      entry.qr = null
      log(userId, `✔ Connected as ${sock.user?.id || "unknown"}`)
    }

    if (connection === "close") {
      entry.status = "disconnected"
      const statusCode = lastDisconnect?.error?.output?.statusCode

      if (statusCode === DisconnectReason.loggedOut) {
        log(userId, "✗ Logged out — clearing session folder")
        cleanupSocket(userId)
        sessions.delete(userId)
        try { fs.rmSync(sessionPath, { recursive: true, force: true }) } catch {}
      } else {
        log(userId, `↻ Disconnected (code ${statusCode}) — reconnecting in 2s`)
        entry.reconnectTimer = setTimeout(() => startSession(userId), 2000)
      }
    }
  })

  sock.ev.on("messages.upsert", async ({ messages, type }) => {
    if (type !== "notify") return

    for (const msg of messages) {
      if (!msg.message || msg.key.fromMe) continue
      try {
        await commandLoader.handle({ sock, msg, userId })
      } catch (e) {
        log(userId, `✗ message handler error: ${e.message}`)
      }
    }
  })

  return sessions.get(userId)
}

/**
 * Closes the websocket and removes listeners for a session's current
 * socket, without touching its auth files. Prevents leaked timers/sockets
 * from old connections when reconnecting.
 */
function cleanupSocket(userId) {
  const entry = sessions.get(userId)
  if (!entry) return

  if (entry.reconnectTimer) clearTimeout(entry.reconnectTimer)

  try {
    entry.sock?.ev?.removeAllListeners()
    entry.sock?.end(undefined)
  } catch {}
}

/**
 * Restore every previously-linked session on boot by scanning /sessions/.
 */
async function loadAllSessions() {
  const userDirs = fs.readdirSync(SESSIONS_DIR).filter((f) =>
    fs.statSync(path.join(SESSIONS_DIR, f)).isDirectory()
  )

  console.log(`[SESSIONS] Found ${userDirs.length} saved session(s) — restoring...`)

  for (const userId of userDirs) {
    // Only restore folders that actually have credentials saved
    const credsPath = path.join(SESSIONS_DIR, userId, "creds.json")
    if (!fs.existsSync(credsPath)) continue

    try {
      await startSession(userId)
    } catch (e) {
      console.error(`[SESSIONS] Failed to restore ${userId}:`, e.message)
    }
  }
}

function getSession(userId) {
  return sessions.get(userId)
}

/**
 * Fully log out and wipe a session's stored credentials.
 */
async function logoutSession(userId) {
  const entry = sessions.get(userId)

  if (entry?.sock) {
    try { await entry.sock.logout() } catch {}
  }

  cleanupSocket(userId)
  sessions.delete(userId)

  const sessionPath = path.join(SESSIONS_DIR, userId)
  try { fs.rmSync(sessionPath, { recursive: true, force: true }) } catch {}

  log(userId, "🚪 Session logged out and wiped")
}

module.exports = {
  startSession,
  loadAllSessions,
  getSession,
  logoutSession,
}
