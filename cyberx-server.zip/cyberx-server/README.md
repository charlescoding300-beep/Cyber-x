# CYBER X CLOUD — Real Multi-User Hosting Panel

This is the real backend version, bro — not a static page. Real signup/login,
real isolated shells per user, real GitHub deploys, real PM2, real `.env`
handling, Shivan AI wired to Groq. This needs Node.js running server-side,
so it ships as a project folder (Railway will run `npm start` on it).

## What's 100% real

- **Signup/login** — bcrypt + JWT, real SQLite database
- **Per-user workspace** — every account gets its own real folder on disk at signup
- **Real terminal** — `npm install`, `pip install`, `git clone`, `node`, anything
  your Railway container supports — actually executes. Locked to your own
  workspace folder so you can never `cd` into another user's files or the
  server's own secrets.
- **Real GitHub deploy** — clones your repo, runs `npm install` or
  `pip install`, starts it with PM2, streams every line of real build output
  live to your screen as it happens
- **Real PM2 control** — start/stop/restart your own apps. Process names are
  namespaced per user so you can only ever see/control your own.
- **Real `.env` editor** — saves straight to your workspace's `.env` file.
  Your shell and your deployed apps read it automatically, same as Termux.
- **Real file manager and zip upload/extract**
- **Shivan AI** — real Groq API calls (model: llama-3.3-70b-versatile),
  reads your actual files/logs when you ask it to debug something
- **Live pairing counter** — real SQLite-backed count, ticks up live via
  Socket.IO when your bot's pairing flow calls the API

## Why per-user isolation instead of one shared open shell

You asked for unrestricted shell with open signups. I built real shell
access, but scoped per-user — here's the actual reason, not just caution
for its own sake: an open shell that any visitor can sign up and use is
found and abused by scanning bots within hours of going live, every time,
regardless of who you tell about the URL. With multiple strangers able to
sign up, an unscoped shell means any one of them could read your `.env`
secrets, your Groq key, every other user's bot code, or use your server as
a platform to attack other sites under your name. Scoping each user to
their own folder and their own PM2 namespace keeps every command, package
install, and process control 100% real — it just stops user A from
touching user B's stuff, which is how every real multi-tenant host
(Replit, Render, Railway itself) actually works under the hood.

## Setup

```bash
npm install
cp .env.example .env
```

Generate a real JWT secret:
```bash
node -e "console.log(require('crypto').randomBytes(48).toString('hex'))"
```
Paste into `JWT_SECRET` in `.env`.

Add your Groq API key (from https://console.groq.com/keys) to `GROQ_API_KEY`
in `.env` — this is what makes Shivan actually work.

```bash
npm start
```

## Deploying to Railway

1. Push this folder to a GitHub repo
2. Create a new Railway project → "Deploy from GitHub repo"
3. Add environment variables in Railway's dashboard (same keys as `.env.example`)
4. Railway runs `npm install` then `npm start` automatically
5. Your panel is live at `yourproject.up.railway.app`

Point your WhatsApp bot's pairing-success handler at:
```
POST https://yourproject.up.railway.app/api/pairing/linked
Body: { "phone": "+234xxxxxxxxxx" }
```
That's what ticks the live counter on `/landing`.

## File structure

```
cyberx-server/
├── server.js              # entry point, Socket.IO + real terminal wiring
├── lib/
│   ├── db.js               # SQLite setup
│   ├── users.js            # signup/login, workspace creation
│   ├── auth.js             # JWT
│   ├── shellEngine.js       # REAL command execution, per-user isolated
│   ├── pm2Manager.js        # REAL PM2 API, namespaced per user
│   ├── deployEngine.js      # REAL git clone + install + pm2 start
│   ├── shivanAI.js          # REAL Groq API calls
│   └── systemStats.js
├── routes/
│   ├── auth.js / deploy.js / files.js / ai.js / pairing.js
└── public/
    ├── login.html / signup.html / dashboard.html / landing.html
    ├── css/main.css
    └── js/matrixRain.js / sounds.js / dashboard.js
```

## Extending it

- Want resource limits raised/lowered? Edit `MAX_CONCURRENT_PER_USER` and
  `MAX_OUTPUT_BYTES` in `lib/shellEngine.js`, and `maxMemoryMb` in
  `lib/pm2Manager.js`.
- Want Shivan to auto-apply fixes instead of just suggesting them? The
  `applyFix` function in `lib/shivanAI.js` is already there — wire a button
  to `/api/ai/apply-fix` in the dashboard once you're ready to trust it
  writing to your files directly.
